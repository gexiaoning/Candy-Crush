package yu.model;

public class User {

	private String username;
	private String password;
	private int highestScore;


	public User(String username, String password, int score) {
		this.username = username;
		this.password = password;
		this.highestScore = score;
	}
	
	// getter method for username
	public String getUsername() {
		return username;
	}
	
	// getter method for score
	public int getHighestScore() {
		return highestScore;
	}
	
	// getter method for password
	public String getPassword() {
		return password;
	}
	
	// method to update the score
	public void updateHighestScore(int highestScore) {
		this.highestScore = highestScore;
	}
}
