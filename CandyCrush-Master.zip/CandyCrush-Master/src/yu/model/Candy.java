package yu.model;

import yu.gui.component.TranslucentButton;
import yu.gui.component.TransparentButton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Candy extends TranslucentButton {

    private int colour;
    public Candy( int colour , int size ) {
        super();
        setPreferredSize( new Dimension( size , size ) );
        setBorder( BorderFactory.createEmptyBorder() );

        setColour( colour );
        setHorizontalAlignment( JButton.CENTER );
    }

    public void setColour(int colour) {
        this.colour = colour;

        if( colour == -1 )
        {
            setIcon( null );
        }
        else
        if( colour == 0 ) {
            setIcon( new ImageIcon(getClass().getResource("/images/weed.gif" )) );
        }
        else {
            setIcon( new ImageIcon(getClass().getResource("/images/candy" + colour + ".png" )));

        }

        setHorizontalAlignment( JButton.CENTER );
    }

}
