package yu.model;

public enum Difficulty {
    HARD,
    EASY,
    MEDIUM
}
