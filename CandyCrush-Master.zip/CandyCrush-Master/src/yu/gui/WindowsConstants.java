package yu.gui;

public class WindowsConstants {
    public static final int INITIAL_X = 400;
    public static final int INITIAL_Y = 100;
    public static final int WIDTH = 700;
    public static final int HEIGHT = 800;
}
