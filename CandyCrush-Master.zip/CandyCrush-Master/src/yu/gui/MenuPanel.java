package yu.gui;

import yu.gui.component.TransparentButton;
import yu.model.Difficulty;
import yu.model.User;

import javax.swing.*;
import java.awt.*;
// need to fix the setBounds
public class MenuPanel extends JFrame {

    private JLabel background = new JLabel( new ImageIcon(getClass().getResource("/images/menuPanelBackground.gif" )));;
    private JComboBox<String> difficultyJComboBox = new JComboBox<>( new String[]{ "EASY" , "MEDIUM" ,"HARD"});

    private TransparentButton startButton = new TransparentButton(new ImageIcon(getClass().getResource("/images/go.png" )));
    private JLabel titleLabel = new JLabel();
    private TransparentButton logOffButton = new TransparentButton( new ImageIcon(getClass().getResource("/images/logOffInMenu.png" )));

    public MenuPanel( User user )
    {
        setBounds( WindowsConstants.INITIAL_X, WindowsConstants.INITIAL_Y,WindowsConstants.HEIGHT, WindowsConstants.WIDTH - 200);

        titleLabel.setText( "Welcome!" + user.getUsername() + ", Choose Your Challenge!");
        titleLabel.setFont( new Font("Serif", Font.BOLD, 30) );
        titleLabel.setForeground( Color.RED );

        startButton.addActionListener( e->{
            Difficulty chosenDifficulty = null;

            switch ( (String)difficultyJComboBox.getSelectedItem() )
            {
                case "EASY": chosenDifficulty = Difficulty.EASY; break;
                case "MEDIUM": chosenDifficulty = Difficulty.MEDIUM; break;
                case "HARD": chosenDifficulty = Difficulty.HARD;
            }

            new GamePanel( user , chosenDifficulty );
            dispose();

        });


        logOffButton.addActionListener( e->{
            new LoginPanel();
            dispose();

        });


        titleLabel.setBounds( 100,150,600,70);
        titleLabel.setHorizontalAlignment( JLabel.CENTER );
        difficultyJComboBox.setBounds( 300 , 170 , 200 ,100  );
        startButton.setBounds( 300,230,200,100);
        logOffButton.setBounds( 300,330 , 200, 100 );

        background.setLayout( null );
        background.add( difficultyJComboBox );
        background.add( startButton );
        background.add( titleLabel );
        background.add( logOffButton );


        add( background );
        setResizable( false );
        setVisible( true );
    }
}
