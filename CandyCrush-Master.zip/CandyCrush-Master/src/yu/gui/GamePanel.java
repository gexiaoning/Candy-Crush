package yu.gui;

import yu.gui.component.TransparentButton;
import yu.model.Difficulty;
import yu.service.UsersDAO;
import yu.model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class GamePanel extends JFrame {


    private Timer timer = null;
    private User user;

    private GridPanel gridPanel = new GridPanel();
    private int lastScore = 0;
    private int timeLeft = 10;

    private Timer scoreTimer = null;
    private JPanel titlePanel = new JPanel();
    private JLabel scoreLabel = new JLabel();
    private JLabel timeLabel = new JLabel();
    private TransparentButton pauseButton = new TransparentButton(new ImageIcon(getClass().getResource("/images/pause.png" )));
    private static UsersDAO usersDAO = UsersDAO.getInstance();
    private JLabel backGround = new JLabel( new ImageIcon(getClass().getResource("/images/gamePanelBackground.jpg" )));
    private TransparentButton timeLeftLabel = new TransparentButton(new ImageIcon(getClass().getResource("/images/timeLeft.png" )) );
    private TransparentButton scoreLogo = new TransparentButton(new ImageIcon(getClass().getResource("/images/score.png" )) );
    public Difficulty getDifficulty() {
        return difficulty;
    }

    public Difficulty difficulty;

    public GamePanel(User user , Difficulty difficulty )
    {
        setBounds( WindowsConstants.INITIAL_X, WindowsConstants.INITIAL_Y,WindowsConstants.WIDTH + 100 , WindowsConstants.HEIGHT + 150);


        this.user = user;
        this.difficulty = difficulty;

        scoreLabel.setHorizontalAlignment( JLabel.CENTER );
        scoreLabel.setFont(new Font("Serif", Font.BOLD, 24));
        scoreLabel.setForeground( Color.YELLOW );

        timeLabel.setHorizontalAlignment( JLabel.CENTER );
        timeLabel.setFont(new Font("Serif", Font.BOLD, 24));
        timeLabel.setForeground(Color.RED);

        pauseButton.addActionListener(e->{
            new PausePanel( this );
            timer.stop();
        });
        pauseButton.setFont(new Font("Serif", Font.BOLD, 24));

        scoreTimer = new Timer(15 , e->{

            int score = gridPanel.getScore();
            scoreLabel.setText( "" + score );
            timeLeft += (int)( (score - lastScore) * 0.7 );
            lastScore = score;
        });

        timer = new Timer( 1000 , e ->{

            timeLabel.setText( "" + --timeLeft );

            if( timeLeft < 0 )
            {
                timer.stop();
                scoreTimer.stop();
                try {
                    user.updateHighestScore(gridPanel.getScore());
                if( gridPanel.getScore() > usersDAO.getUserHighestScore( user ) ) {
                    usersDAO.updateHighestScores(user);
                }
                } catch (SQLException sqlE) {
                sqlE.getSQLState();
            }
                dispose();
                new EndPanel(user , difficulty);
            }

        });

        scoreTimer.start();
        timer.start();

        titlePanel.setLayout( new GridLayout(0,5 ));

        titlePanel.add( scoreLogo );
        titlePanel.add( scoreLabel  );
        titlePanel.add( timeLeftLabel );
        titlePanel.add( timeLabel );
        titlePanel.add(pauseButton);
        titlePanel.setOpaque( false );

        backGround.setLayout( new BoxLayout( backGround , BoxLayout.Y_AXIS  ) );

        backGround.add( titlePanel );
        backGround.add( gridPanel  );

        add( backGround );
        setResizable( true );
        setVisible( true );

    }

    public int getTimeLeft() {
        return timeLeft;
    }
    public void setTimeLeft(int timeLeft) {
        this.timeLeft = timeLeft;
    }
    public Timer getTimer() {
        return timer;
    }
    public User getUser() {
        return user;
    }

}
