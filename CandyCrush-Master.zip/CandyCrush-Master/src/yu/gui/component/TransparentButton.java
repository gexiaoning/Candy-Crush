package yu.gui.component;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class TransparentButton extends JButton {

    public TransparentButton( String text )
    {
        super( text );
        setOpaque( false );
        setContentAreaFilled(false);
        setOpaque( false );
        setBorder( BorderFactory.createEmptyBorder() );

        addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e ) {

                setFont( getFont().deriveFont( getFont().getSize() + 6f  ));

            }

            public void mouseExited( MouseEvent e ) {

                setFont( getFont().deriveFont( getFont().getSize() - 6f  ));
            }
        });

    }
    public TransparentButton( Icon icon )
    {
        super( icon );
        setOpaque( false );
        setContentAreaFilled(false);
        setOpaque( false );
        setBorder( BorderFactory.createEmptyBorder() );
        addMouseListener(new MouseAdapter() {

            public void mouseEntered(MouseEvent e ) {

                setBorder( BorderFactory.createMatteBorder( 1,1,1, 1, Color.cyan));

            }

            public void mouseExited( MouseEvent e ) {

                setBorder( BorderFactory.createEmptyBorder() );
            }
        });
    }

    public TransparentButton(  )
    {
        setContentAreaFilled(false);
        setOpaque( false );
        setBorder( BorderFactory.createEmptyBorder() );
        addMouseListener(new MouseAdapter() {

            public void mouseEntered(MouseEvent e ) {

                //setBorder( BorderFactory.createMatteBorder( 1,1,1, 1, Color.cyan));

            }

            public void mouseExited( MouseEvent e ) {

                //setBorder( BorderFactory.createEmptyBorder() );
            }
        });
    }

}
