package yu.gui;

import yu.model.Candy;
import yu.service.Refresh;

import javax.swing.*;
import java.awt.*;

public class GridPanel extends JPanel {


    private static final int SIZE = 7;
    private static final int MOVE_DELAY = 20;
    private static final int SHOW_DELAY = 10;


    private int[][] elements = new int[SIZE][SIZE];
    private Boolean selectedFirst = false;
    private int[] selectedCandyCoord = new int[2];
    private Candy selectedCandy = null;


    public int getScore() {
        return score;
    }

    private int score = 0;

    //ExecutorService executor = Executors.newCachedThreadPool();

    Candy[][] candies = new Candy[SIZE][SIZE];
    Boolean[][] removed = new Boolean[SIZE][SIZE];

    public GridPanel( ) {

        setBounds( 50 , 50 , 700 , 700);
        setMaximumSize( new Dimension( 700 ,700 ));
        setLayout( new GridLayout(SIZE, SIZE) );

        setOpaque( false );
        elements = Refresh.init( elements );
        setupGrid();

    }

    private void setupGrid()
    {
        for(int i = 0; i < SIZE; i++ )
            for(int j = 0; j < SIZE; j++ ) {

                int[] curCoordinate = new int[]{ i , j };
                Candy curCandy = new Candy( elements[i][j] , 700 / SIZE);
                candies[i][j] = curCandy;

                curCandy.addActionListener( e -> {
                    ButtonAction( curCandy,  curCoordinate );
                });

                add( curCandy );
            }
    }

    private void refreshGrid() throws InterruptedException {
        // 1.detect the row and remove those candies

        int flag = 0;

        while( flag == 0 ) {

            flag = 1;
            while (detectRemoved() != 0) {

                Thread.sleep(500);
                compress();
                generateNew(60);
                Thread.sleep( 200 );
            }

            while ( Refresh.isDeadMap( elements ) ) {
                System.out.println("detected a deadMap");
                flag = 0;

                for( int i = 0 ; i < SIZE ; i++ )
                    for( int j = 0; j < SIZE ; j++ )
                    {
                        candies[i][j].setColour( -1 );
                        elements[i][j] = 0;
                    }
                generateNew( 0 );
            }

            System.out.println(score);

        }


        // 2.let the holes go down

        // 3.let the new candies generate from the top

        // 4.check whether or not there are some candies that need to be removed( go to 1) until the graphy is stable( no candies are created

        // 5.check is a deadmap( if is a deadmap set the elements all to zero and go to 1 )

        // 6.
    }

    private int detectRemoved()
    {
        int count = 0;

        for( int i = 0 ; i < SIZE ; i++ )
            for( int j = 0 ; j < SIZE ; j++ ) {

                removed[i][j] = false;
                if( Refresh.isRemoved(elements,i,j) ) {
                    removed[i][j] = true;
                    candies[i][j].setColour(0);
                    count++;
                }

            }
            score += count;
            return count;
    }

    private void compress( ) {

        int[] peakPointer = new int[SIZE];
        int[] pos = new int[SIZE];

        for( int i = 0 ; i < SIZE ; i++ ) {
            pos[i] = SIZE - 1;
        }

        int flag = 1;

        while( flag == 1) {
            flag = 0;

            for (int j = 0; j < SIZE; j++) {

                while (pos[j] >= peakPointer[j] && removed[pos[j]][j] == false) {
                    pos[j]--;
                }
                int k = pos[j];

                if( k >= peakPointer[j] ) {
                    while (k > peakPointer[j]) {
                        flag = 1;
                        elements[k][j] = elements[k - 1][j];
                        removed[k][j] = removed[k - 1][j];
                        candies[k][j].setColour(elements[k][j]);
                        k--;
                    }
                    elements[peakPointer[j]][j] = 0;
                    removed[peakPointer[j]][j] = false;
                    candies[peakPointer[j]][j].setColour(-1);
                    peakPointer[j]++;
                }
            }

            try {
                Thread.sleep(70);
            }catch ( InterruptedException e )
            {
                e.printStackTrace();
            }

        }


    }


    private void generateNew( int sleepTime )
    {
        //
        int[] bounds = new int[ SIZE ];
        int i,j;

        // find the bottom holes
        for(  j = 0 ; j < SIZE ; j++ ) {
            for ( i = 0; i < SIZE && elements[i][j] == 0; i++) {
                ;
            }
            bounds[j] = i;
        }


        // point at next possible holes
        int[] pointer = new int[ SIZE ];
        // ->
        for( i = 0 ; i < SIZE ; i++ )
        {
            // could move forward
            while( pointer[i] < bounds[i] )
            {
                for( int k = pointer[i] ; k > 0 ; k-- )
                {
                    elements[k][i] = elements[k-1][i];
                    //System.out.println( "i = " + i + " k = " + k + elements[k][j] );
                    candies[k][i].setColour( elements[k][i] );
                    candies[k][i].setVisible(true);
                    try {
                        Thread.sleep(sleepTime );
                    }catch ( InterruptedException e )
                    {
                        e.printStackTrace();
                    }
                }
                elements[0][i] = (int)(Math.random() * 6) + 1;
                candies[0][i].setColour( elements[0][i] );

                pointer[i]++;
            }
        }

    }


    private void ButtonAction( Candy curButton , int[] curCoordinate ) {

        if( !selectedFirst ) {

            selectedCandy = curButton;
            selectedCandyCoord[0] = curCoordinate[0];
            selectedCandyCoord[1] = curCoordinate[1];

            //curButton.setBorder( BorderFactory.createMatteBorder(2,2,2,2,Color.blue));

            selectedFirst = true;
        }
        else{

            if( canSwap( curCoordinate , selectedCandyCoord ) )
            {
                curButton.setColour(  elements[curCoordinate[0]][curCoordinate[1]] );
                selectedCandy.setColour(  elements[selectedCandyCoord[0]][selectedCandyCoord[1]] );

                new RefreshWorker().execute();
            }
            //selectedCandy.setBorder( BorderFactory.createEmptyBorder() );
            selectedFirst = false;
        }

    }

    private boolean canSwap( int[] a , int[] b )
    {

        if( a[0] == b[0] - 1 || a[0] == b[0] + 1 || a[1] == b[1] + 1 || a[1] == b[1] - 1 )
        {
            int aValue = elements[ a[0] ][ a[1] ];
            int bValue = elements[ b[0] ][ b[1] ];
            elements[ a[0] ][ a[1] ] = bValue;
            elements[ b[0] ][ b[1] ] = aValue;

            if( Refresh.isRemoved( elements , a[0], a[1]) || Refresh.isRemoved( elements , b[0] , b[1]) )
            {
                return true;
            }
            else
            {
                elements[ a[0] ][ a[1] ] = aValue;
                elements[ b[0] ][ b[1] ] = bValue;
                return false;
            }
        }
        return false;
    }

    class RefreshWorker extends SwingWorker<Void,int[]>
    {
        @Override
        protected Void doInBackground() throws Exception {
            refreshGrid();

            return null;
        }

    }


}

