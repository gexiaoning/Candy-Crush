package yu.gui;

import yu.gui.component.TransparentButton;
import yu.service.UsersDAO;
import yu.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;

public class LoginPanel extends JFrame implements ActionListener {

    private JLabel titleLabel = new JLabel(new ImageIcon(getClass().getResource("/images/whateverCrush.png")) );
    private JLabel usernameLabel = new JLabel("USERNAME", SwingConstants.CENTER);
    private JLabel passwordLabel = new JLabel("PASSWORD", SwingConstants.CENTER);
    private JTextField usernameText = new JTextField();
    private JPasswordField passwordText = new JPasswordField();
    private TransparentButton loginButton = new TransparentButton(new ImageIcon(getClass().getResource("/images/login.png" )) );
    private TransparentButton registerButton = new TransparentButton(new ImageIcon(getClass().getResource("/images/register.png" )));
    private JPanel inputPanel = new JPanel();
    private JPanel mainPanel = new JPanel();
    private JLabel backGround = new JLabel( new ImageIcon(getClass().getResource("/images/loginBackground.gif" )) );

    private UsersDAO usersDAO = UsersDAO.getInstance();

    private JPanel buttonPanel = new JPanel();

    public static void main( String[] args )
    {
        SwingUtilities.invokeLater( ()->{
            new LoginPanel();
        });
    }

    public LoginPanel()
    {
        setBounds( WindowsConstants.INITIAL_X, WindowsConstants.INITIAL_Y,WindowsConstants.WIDTH, WindowsConstants.HEIGHT);

        usernameText.setPreferredSize( new Dimension( 250 , 30 ));
        usernameText.setMaximumSize( usernameText.getPreferredSize() );

        passwordText.setPreferredSize( new Dimension( 250 , 30 ));
        passwordText.setMaximumSize( usernameText.getPreferredSize() );

        buttonPanel.setLayout( new BorderLayout( 0 , 30 ) );
        buttonPanel.add( loginButton , BorderLayout.NORTH );
        buttonPanel.add( registerButton , BorderLayout.CENTER );
        buttonPanel.setOpaque(false);

        inputPanel.setOpaque( false );
        inputPanel.setLayout( new FlowLayout() );

        inputPanel.add( usernameLabel );
        inputPanel.add( usernameText );
        inputPanel.add( passwordLabel );
        inputPanel.add( passwordText );
        inputPanel.add( buttonPanel );

        mainPanel.setLayout( new BorderLayout( 0 , 200) );
        mainPanel.add( titleLabel , BorderLayout.NORTH );
        mainPanel.add( inputPanel , BorderLayout.CENTER );
        mainPanel.setOpaque(false);



        backGround.setLayout( new BorderLayout()  );
        backGround.add( mainPanel ,BorderLayout.CENTER );

        registerButton.setFont( new Font("Times", Font.BOLD, 24) );
        registerButton.setForeground( Color.ORANGE );

        loginButton.setFont( new Font( "Serif" , Font.BOLD , 24 ) );
        loginButton.setForeground( Color.RED );

        add( backGround );
        addActionEvent();//calling addActionEvent() method
        setResizable( false );
        setVisible( true );

    }

   
   public void addActionEvent()
   {
      //adding Action listener to components
       loginButton.addActionListener(this);
       registerButton.addActionListener(this);

   }

    @Override
    public void actionPerformed(ActionEvent e) {
    	if(e.getSource() == registerButton) {
    		new RegisterPanel();
    	}
    	else
    	if (e.getSource() == loginButton) {
    		// check if username and password match
    		String username = usernameText.getText();
    		String password = String.copyValueOf(passwordText.getPassword());
    		
    		try {
				if ( usersDAO.login(username, password)) {
					// loginButton was successful
					JOptionPane.showMessageDialog(null, "Login Successful!", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);
					usernameText.setText("");
					passwordText.setText("");
					new MenuPanel( new User(username,password,0) );
					dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
					passwordText.setText("");
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
    	}
    }
}
