package yu.gui;

import yu.gui.component.TransparentButton;
import yu.model.Difficulty;
import yu.service.UsersDAO;
import yu.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;

import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class EndPanel extends JFrame {

	
	private JPanel header;
	private JScrollPane scoresListPanel;
	private ArrayList<User> topScores;
	private JLabel background = new JLabel( new ImageIcon(getClass().getResource("/images/endPanelBackground.gif" )));

	private TransparentButton logOffButton = new TransparentButton( new ImageIcon(getClass().getResource("/images/logOff.png" )));
	private TransparentButton playAgainButton = new TransparentButton( new ImageIcon(getClass().getResource("/images/playAgain.png" )));
	private JLabel lightTitle = new JLabel( new ImageIcon(getClass().getResource("/images/gameOver.png" )));
	private JLabel endPageTitle  = null;
	private JLabel scoresTitle = new JLabel(new ImageIcon(getClass().getResource("/images/highScores.png" )));
	private JTable scoreList = null;
	private JPanel backButtonsPanel = new JPanel();
	private TransparentButton changeButton = new TransparentButton(new ImageIcon(getClass().getResource("/images/menu.png" )));
	private JPanel topPanel = new JPanel();
	private JLabel yourScoreLabel = new JLabel( new ImageIcon(getClass().getResource("/images/yourScore.png" )));


	public EndPanel( User user , Difficulty difficulty ) {
		// set frame layout
		setBounds( WindowsConstants.INITIAL_X, WindowsConstants.INITIAL_Y,WindowsConstants.WIDTH + 100, WindowsConstants.HEIGHT );

		setLayout( new BorderLayout() );


		
		// create the header JPanel
		header = new JPanel();
		header.setLayout(new BorderLayout(0, 20));


		endPageTitle = new JLabel( "" + user.getHighestScore(), SwingConstants.CENTER);
		endPageTitle.setFont(new Font("Serif", Font.BOLD, 40));
		endPageTitle.setForeground( Color.RED );

		topPanel.setOpaque(false);
		topPanel.setLayout( new BorderLayout() );

		scoresTitle.setFont(new Font("Serif", Font.BOLD, 24));
		scoresTitle.setForeground( Color.cyan );

		topPanel.add( lightTitle , BorderLayout.NORTH );
		topPanel.add( yourScoreLabel , BorderLayout.CENTER );

		header.add(endPageTitle, BorderLayout.CENTER);
		header.add(scoresTitle, BorderLayout.SOUTH);
		header.add( topPanel , BorderLayout.NORTH );
		header.setOpaque( false );

		logOffButton.setIcon( new ImageIcon( getClass().getResource("/images/logOff.png" )));
		// create JPanel to hold the top scores

		
		// create a ScorePanel for each high score using scores from the database
		try {
			// get the top scores from database 
			topScores = UsersDAO.getInstance().getTopTenScores();
			// create ScorePanels for each top-scoring user
		} catch (SQLException e) {
			e.printStackTrace();
		}

		String[][] data = new String[topScores.size()][2];

		for( int i = 0 ; i < topScores.size() ; i++ )
		{
			data[i][0] = topScores.get(i).getUsername();
			data[i][1] = String.valueOf( topScores.get(i).getHighestScore() );
		}

		// Column Names
		String[] columnNames = { "Name", "Highest Score" };

		// Initializing the JTable

		DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
		rightRenderer.setHorizontalAlignment(JLabel.CENTER);


		scoreList = new JTable(data, columnNames);

		scoreList.setFont(new Font("Serif", Font.BOLD, 18));
		scoreList.getColumnModel().getColumn(0).setCellRenderer(rightRenderer);
		scoreList.getColumnModel().getColumn(1).setCellRenderer(rightRenderer);

		scoreList.setShowGrid(false);
		scoreList.setOpaque( false );
		scoreList.getTableHeader().setOpaque(false);
		scoreList.setTableHeader( null );
		scoreList.setForeground( Color.cyan );
		scoreList.setBackground( new Color(0, 0, 0, 0) );

		scoresListPanel = new JScrollPane(scoreList);
		scoresListPanel.getViewport().setOpaque(false);
		scoresListPanel.setOpaque( false );
		scoresListPanel.setBorder( BorderFactory.createEmptyBorder() );

		// add the header and scoresList panels to JFrame
		backButtonsPanel.setLayout( new FlowLayout( FlowLayout.CENTER,30,0) );


		playAgainButton.setForeground( Color.cyan );
		playAgainButton.addActionListener( e-> {
			new GamePanel( user ,  difficulty );
			dispose();
		});
		playAgainButton.setFont(new Font("Serif", Font.BOLD, 24));


		logOffButton.setForeground( Color.cyan );
		logOffButton.addActionListener( e->{
			new LoginPanel();
			dispose();
		});
		logOffButton.setFont(new Font("Serif", Font.BOLD, 24));

		changeButton.setForeground( Color.cyan );
		changeButton.addActionListener( e->{
			new MenuPanel(user);
			dispose();
		});
		changeButton.setFont(new Font("Serif", Font.BOLD, 24));

		backButtonsPanel.setLayout( new GridLayout( 0 ,1 ) );
		backButtonsPanel.add(playAgainButton);
		backButtonsPanel.add(logOffButton);
		backButtonsPanel.add( changeButton );
		backButtonsPanel.setOpaque( false );



		background.setLayout( new BorderLayout() );
		background.add( header, BorderLayout.NORTH);
		background.add( scoresListPanel, BorderLayout.CENTER);
		background.add( backButtonsPanel ,BorderLayout.SOUTH);


		add(background);

		setResizable( false );
		setVisible( true );
	}


}
