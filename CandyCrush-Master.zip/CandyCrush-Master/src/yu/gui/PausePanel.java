package yu.gui;

import yu.gui.component.TransparentButton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class PausePanel extends JFrame {

    private JLabel background = new JLabel( new ImageIcon(getClass().getResource("/images/pausePanelBackground.gif" )) );
    private JButton endButton = new JButton( "END GAME" );
    private JButton resumeButton = new JButton( "RESUME" );
    private JButton restartButton = new JButton( "RESTART");

    public PausePanel( GamePanel gamePanel )
    {
        setBounds( WindowsConstants.INITIAL_X + 100, WindowsConstants.INITIAL_Y + 100,WindowsConstants.WIDTH -200, WindowsConstants.HEIGHT -200);

        resumeButton.setForeground( Color.orange );
        resumeButton.addActionListener( e->{
            gamePanel.getTimer().start();
            dispose();
        });
        resumeButton.setFont(new Font("Serif", Font.BOLD, 24));

        endButton.setForeground( Color.orange );
        endButton.addActionListener( e-> {

            gamePanel.dispose();
            new MenuPanel( gamePanel.getUser() );
            dispose();
            //new MenuPanel( gamePanel.user );
        });
        endButton.setFont(new Font("Serif", Font.BOLD, 24));

        restartButton.setForeground( Color.orange );
        restartButton.addActionListener( e->{
            new GamePanel( gamePanel.getUser() , gamePanel.getDifficulty() );
            gamePanel.dispose();
            dispose();
        });
        restartButton.setFont(new Font("Serif", Font.BOLD, 24));

        resumeButton.setBounds( 150 , 100 , 200,40 );
        restartButton.setBounds( 150 , 300 , 200,40 );
        endButton.setBounds( 150 , 500 , 200,40 );


        background.setLayout( null );
        background.add( restartButton );
        background.add( endButton );
        background.add( resumeButton );

        addWindowListener(new WindowAdapter()
        {
            @Override
            public void windowClosing(WindowEvent e)
            {
                gamePanel.getTimer().start();
                e.getWindow().dispose();
            }
        });


        add(background);
        setResizable( false );
        setVisible( true );
    }
}
