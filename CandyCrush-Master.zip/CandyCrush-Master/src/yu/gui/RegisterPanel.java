package yu.gui;

import yu.service.UsersDAO;
import yu.model.User;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterPanel extends JFrame implements ActionListener {

    private JLabel userNameLabel = new JLabel("USERNAME");
    private JLabel passwordLabel = new JLabel("PASSWORD");
    private JLabel reentryPasswordLabel = new JLabel("RE-TYPE PASSWORD");
    private JTextField userNameText = new JTextField();
    private JPasswordField passwordText = new JPasswordField();
    private JPasswordField reentryPassWordText = new JPasswordField();
    
    private JButton registerButton = new JButton("REGISTER");
    private JButton backButton = new JButton("RETURN TO LOGIN");

    private JLabel backGround = new JLabel( new ImageIcon(getClass().getResource("/images/registerBackground.gif" )) );
    private static UsersDAO usersDAO = UsersDAO.getInstance();

    public RegisterPanel()
    {
        setBounds( WindowsConstants.INITIAL_X + 100, WindowsConstants.INITIAL_Y + 100,WindowsConstants.WIDTH -250, WindowsConstants.HEIGHT-300);


        setLocationAndSize();
        addActionEvent();//calling addActionEvent() method

        backGround.setLayout( null );
        backGround.add( userNameLabel );
        backGround.add( userNameText );
        backGround.add( reentryPasswordLabel );
        backGround.add( passwordLabel);
        backGround.add( passwordText );
        backGround.add( reentryPassWordText );
        backGround.add( registerButton );

        add( backGround );
        setResizable( false );
        setVisible( true );
    }


   public void setLocationAndSize()
   {

	   userNameLabel.setBounds(50,150,190,30);
       passwordLabel.setBounds(50,220,190,30);
       reentryPasswordLabel.setBounds(50,290,190,30);
       userNameText.setBounds(190,150,150,30);
       passwordText.setBounds(190,220,150,30);
       reentryPassWordText.setBounds(190,290,150,30);
       backButton.setBounds(200,400,160,30);
       registerButton.setBounds(170,400,100,30);

   }

   public void addActionEvent()
   {
      //adding Action listener to components
       // backButton.addActionListener(this);
       registerButton.addActionListener(this);
   }


    @Override
    public void actionPerformed(ActionEvent e) {
    	if(e.getSource()== registerButton) {
    		// get the username and password that user typed in
    		String username = userNameText.getText();
    		String password = String.valueOf(passwordText.getPassword());
    		String rePassword = String.valueOf(reentryPassWordText.getPassword());
    		
    		// make sure password and retyped password match
    		if (!password.equals(rePassword)) {
    			JOptionPane.showMessageDialog(null, "Re-typed password doesn't match, please try again.", "ERROR", JOptionPane.INFORMATION_MESSAGE);
    		}
    		// proceed to storing entered username and password into database
    		else {
    			// check if username already exists in database
    			try {
					if ( usersDAO.checkUsername(username)) {
						JOptionPane.showMessageDialog(null, "Username already exists. Please try again", "ERROR", JOptionPane.INFORMATION_MESSAGE);
					}
					else {
						// go ahead and registerButton new user - insert the username and password and initial score of 0 into DB
						User player = new User(username, password, 0);
		    			try {
							usersDAO.insertUser(player);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} 
					}
					JOptionPane.showMessageDialog(null, "Registration successful!", "SUCCESS", JOptionPane.INFORMATION_MESSAGE);
					
					// go back to loginButton page
			        dispose();

				} catch (HeadlessException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}    			   			
    		}
    		// reset text fields to empty
    		userNameText.setText("");
			passwordText.setText("");
			reentryPassWordText.setText("");
    	}
    }

}
