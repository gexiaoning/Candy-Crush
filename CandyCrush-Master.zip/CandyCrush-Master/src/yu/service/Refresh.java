package yu.service;

import java.util.HashSet;
import java.util.Set;

// First remove elements which are 3 matched, Then fill the holes on top
public class Refresh {

    public static int[][] init( int[][] board )
    {
        int numberOfRepopulation = -1;
        int flag = 1;

        // ensure it ain't a dead map
        while ( flag == 1 ) {

            flag = 0;
            // output the next stable state
            // check there if is no holes in the array is stable
            while (numberOfRepopulation != 0) {
                boolean[][] removed = new boolean[board.length][board[0].length];
                int numberOfRemoved = -1;

                // shift the holes
                while (numberOfRemoved != 0) {
                    int peakPointer;
                    // bottom-up scan
                    for (int j = 0; j < board[0].length; j++) {
                        peakPointer = 0;
                        for (int i = board.length - 1; i >= peakPointer; i--) {
                            while (peakPointer < board.length && removed[i][j]) {
                                // let the holes go up
                                for (int k = i; k > peakPointer; k--) {
                                    board[k][j] = board[k - 1][j];
                                    removed[k][j] = removed[k - 1][j];
                                }

                                board[peakPointer][j] = 0;
                                removed[peakPointer][j] = false;
                                peakPointer++;
                            }
                        }
                    }

                    // check whether the elements to be removed
                    removed = new boolean[board.length][board[0].length];
                    numberOfRemoved = 0;
                    for (int i = 0; i < board.length; i++)
                        for (int j = 0; j < board[0].length; j++) {
                            if (board[i][j] != 0 && isRemoved(board, i, j)) {
                                removed[i][j] = true;
                                numberOfRemoved++;
                            }
                        }
                }

                // fill the holes
                numberOfRepopulation = fillHoles(board);
            }

            // check whether this is a deadMap
            while( isDeadMap(board) ) {
                board = new int[board.length][board[0].length];
                // fully get a new map
                fillHoles( board );
                flag = 1;
            }
        }
        return board;
    }

    /*
    1 2 3
    4 c 6
    7 8 9

     */
    public static boolean isDeadMap( int[][] board )
    {
        for ( int i = 0 ; i < board.length ; i++ )
            for ( int j = 0 ; j < board[0].length ; j++ ) {
                Set<Integer> set = new HashSet<>();
                int cur = board[i][j];
                if( i > 0 ) {
                    if( j > 0 && board[i-1][j-1] == cur )
                        set.add( 1 );
                    if( board[i-1][j] == cur )
                        set.add( 2 );
                    if( j < board[0].length - 1 && board[i-1][j+1] == cur )
                        set.add( 3 );
                }
                if( i < board.length - 1 ) {
                    if( j > 0 && board[i+1][j-1] == cur )
                        set.add( 7 );
                    if( board[i+1][j] == cur )
                        set.add( 8 );
                    if( j < board[0].length - 1 && board[i+1][j+1] == cur )
                        set.add( 9 );
                }
                if( j > 0 && board[i][j-1] == cur )
                    set.add( 4 );
                if( j < board[0].length - 1 && board[i][j+1] == cur )
                    set.add( 6 );

                if( set.contains(1) && (set.contains(3) || set.contains(7) || set.contains(6) || set.contains(8) )) {
                    return false;
                }
                if( set.contains(3) && ( set.contains(4) || set.contains(8) || set.contains(9) )) {
                    return false;
                }
                if ( set.contains(7) && ( set.contains(9) || set.contains(6) || set.contains(2) )) {
                    return false;
                }
                if( set.contains(9) && ( set.contains(2) || set.contains(4) )) {
                    return false;
                }
            }

            return  true;
    }
    // try to improve later
    // return the holes that have been filled
    private static int fillHoles( int[][] board )
    {
        int count = 0;
        for ( int j = 0 ; j < board[0].length ; j++ )
           for ( int i = 0 ; i < board.length && board[i][j] == 0; i++ ) {
               board[i][j] = (int)(Math.random() * 6) + 1;
               count++;
           }
        return count;
    }

    public static boolean isRemoved( int[][] board , int row , int col )
    {

        final int LEFT = Math.max( 0 , row - 2 );
        final int RIGHT = Math.min( board[0].length - 1 , row + 2 );
        final int TOP = Math.max( 0 , col - 2 );
        final int BOTTOM = Math.min( board.length - 1 , col + 2 );
        int count = 0;
        int curCandy = board[row][col];

        // check the horizontal direction
        for ( int i = LEFT; i <= RIGHT; i++ ) {
            if( board[i][col] == curCandy ) {
                count++;
                if( count >= 3  )
                    return true;
            }
            else {
                count = 0;
            }
        }

        count = 0;
        // check the vertical direction
        for ( int i = TOP; i <= BOTTOM; i++ ) {
            if( board[row][i] == curCandy ) {
                count++;
                if( count >= 3  )
                    return true;
            }
            else {
                count = 0;
            }
        }

        return false;
    }
}
