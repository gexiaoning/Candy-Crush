package yu.service;

import yu.model.User;

import java.sql.*;
import java.util.ArrayList;

public class UsersDAO {

	// JDBC driver name and database URL
    private static final String JDBC_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String DB_URL = "jdbc:derby:usersDB;create=true;user=username;password=password";
    
    // Database credentials
    private static final String USER = "username";
    private static final String PASS = "password";
    
    private static Connection conn = null;
    private static Statement stmt = null;
    private static UsersDAO usersDatabase = new UsersDAO();
    
    // Register page
    private UsersDAO() {
    	
    	try{
	        //STEP 2: Register JDBC driver
	        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

	        //STEP 3: Open a connection
	        System.out.println("Connecting to database...");
	        conn = DriverManager.getConnection(DB_URL, USER, PASS);

	        //STEP 4: Execute a query
	        System.out.println("Creating database...");
	        stmt = conn.createStatement();
	        System.out.println("Checking database for table");
	        DatabaseMetaData dbMetaData = conn.getMetaData();
	        ResultSet rs = dbMetaData.getTables(null, null, "USERS", null);
	        
	        if (rs.next()) {
	        	System.out.println("Table found.");
	        }
	        else {
	        	String sql = "CREATE TABLE USERS (" +
						"USERNAME VARCHAR(100), " +
						"PASSWORD VARCHAR(100), " +
						"SCORE INT)";
	        	stmt.executeUpdate(sql);
		        System.out.println("Database created successfully...");
	        }
	     }catch(SQLException se){
	        //Handle errors for JDBC
	        se.printStackTrace();
	     }catch(Exception e){
	        //Handle errors for Class.forName
	        e.printStackTrace();
	     }
    }
    
    // Method to insert data into database - takes in a SQL insert query string
    public static void insertUser(User user) throws SQLException {
    	String INSERT_QUERY = "INSERT INTO USERS (USERNAME, PASSWORD, SCORE) VALUES ('" + user.getUsername() + "', '" + user.getPassword() + "', " + user.getHighestScore() + ")";
    	stmt.executeUpdate(INSERT_QUERY);
    }
    
    // Method checks to see if username already exists in the database
    public static boolean checkUsername(String usrName) throws SQLException {
    	String SELECT_QUERY = "SELECT USERNAME FROM USERS WHERE USERNAME='" + usrName + "'";
    	ResultSet usrData = stmt.executeQuery(SELECT_QUERY);
    	return usrData.next();
    }
    
    // Login method - validate entered username and password
    public boolean login(String username, String password) throws SQLException {
    	// see if combination of the entered username and password exists in the database
    	String SELECT_QUERY = "SELECT USERNAME FROM USERS WHERE USERNAME='" + username + "' AND PASSWORD='" + password + "'";
    	ResultSet uData = stmt.executeQuery(SELECT_QUERY);
    	
    	return uData.next();
    }
    
    // Method to get score from database
    public int getUserHighestScore( User user ) throws SQLException {
    	String SELECT_QUERY = "SELECT SCORE FROM USERS WHERE USERNAME='" + user.getUsername() + "'";
    	ResultSet usrData = stmt.executeQuery(SELECT_QUERY);
    	
    	if (usrData.next()) {
    		return usrData.getInt("SCORE");
    	}
    	else {
    		return -1;
    	}
    }
    
    // Method to update a player's score in the database
    public void updateHighestScores(User user) throws SQLException {
    	String UPDATE_QUERY = "UPDATE USERS SET SCORE= " + user.getHighestScore() + " WHERE USERNAME=" + "'" + user.getUsername() + "'";
    	stmt.executeUpdate(UPDATE_QUERY);
    }

    public void deleteUser( User user ) throws SQLException {
		String UPDATE_QUERY = "DELETE FROM  USERS  WHERE USERNAME=" + "'" + user.getUsername() + "'";
		stmt.executeUpdate(UPDATE_QUERY);
	}
    // Method to get top 10 scores in database
    public ArrayList<User> getTopTenScores() throws SQLException {
    	String SELECT_QUERY = "SELECT USERNAME, PASSWORD, SCORE FROM USERS ORDER BY SCORE DESC";
    	ResultSet usrData = stmt.executeQuery(SELECT_QUERY);    	
    	usrData.next();
    	
    	// return an arrayList of users with highest n scores
    	ArrayList<User> topScores = new ArrayList<User>();
    	for (int i = 0; i < 10; i++) {
    		User player = new User(usrData.getString("USERNAME"), usrData.getString("PASSWORD"), usrData.getInt("SCORE"));
    		if( !usrData.next() )
			{
				break;
			}
    		topScores.add(player);
    	}
    	return topScores;
    }
    
    
    // Method to print out current contents of users table (for testing purposes)
    public void printTable(String SELECT_QUERY) throws SQLException {
    	System.out.printf("Table of Users Database: %n%n");
    	ResultSet userData = stmt.executeQuery(SELECT_QUERY);
    	ResultSetMetaData metaData = userData.getMetaData();
    	int numColumns = metaData.getColumnCount();

    	// display names of columns in authorData result set
    	for (int i = 1; i <= numColumns; i++) {
    		System.out.printf("%-8s\t", metaData.getColumnName(i));
    	}
    	System.out.println();
    	
    	// display query results
    	while (userData.next()) {
    		for (int i = 1; i <= numColumns; i++) {
    			System.out.printf("%-8s\t", userData.getObject(i));
    		}
    		System.out.println();
    	}
    }

    public static UsersDAO getInstance()
	{
		return usersDatabase;
	}
}
